import Head from 'next/head';
import Image from 'next/image';
import './styles.css';

function LoginPage() {
  return (
    <div className="container">
      <Head>
        <title>University of Ghana - Student Login</title>
      </Head>
      <main>
        {/* Align the image to the left */}
        <div style={{ display: 'flex' }}>
          <a href="/">
            <Image src="/UofGjpg.jpg" alt="University of Ghana Logo" width={100} height={50} />
          </a>
        </div>
        <div className="login-box">
          <h2 className="login-title">Sign In</h2>
          <form>
            <label>
              Student ID:
              <input type="text" name="studentId" />
            </label>
            <br />
            <label>
              Password:
              <input type="password" name="password" />
            </label>
            <br />
            <button type="submit">Sign In</button>
          </form>
        </div>
      </main>
      {/* Navigation bar with transparent background */}
      <nav className="transparent-nav">
        <a href="/about" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>About UG</u>
        </a>
        <a href="/research" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Research</u>
        </a>
        <a href="/education" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Education</u>
        </a>
        <a href="/news" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>News</u>
        </a>
        <a href="/campus-life" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Campus Life</u>
        </a>
        <a href="/alumni" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Alumni</u>
        </a>
        <a href="/contact" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Contact</u>
        </a>
      </nav>
    </div>
  );
}

export default LoginPage;

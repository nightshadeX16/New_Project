import React from 'react';

const Header = () => {
    return (
        <header className = 'dashboard-header'>
            <h1>My Dashboard</h1>

        </header>

    );

};

export default Header;
import Head from 'next/head';
import Image from 'next/image';
import './styles.css';

function LoginPage() {
  return (
    <div className="container ">
      <Head>
        <title>University of Ghana - Student Login</title>
      </Head>
      <main>
        {/* Align the image to the left */}
        <div style={{ display: 'flex' }} >
          <a href="/">
            <Image src="/UofGjpg.jpg" alt="University of Ghana Logo" width={100} height={50} className='flex' />
          </a>
        </div>
        <div className="login-box flex flex-col mx-auto my-0">
          <h2 className="login-title mt-[15px]">Sign Up</h2>
          <form>
            <div className=' flex flex-col m'>
              <div className='flex flex-row'>
                <label>
                    <p>First Name</p>
                    <input type="text" name="first_name" className='w-[200px] mr-5' />
                  </label>
                    
                  <label >
                    <p>Last Name:</p>
                    <input type="text" name="last_name" className='w-[200px]'/>
                </label>
                    
              </div>
                <label>
                  <p>Phone Number:</p>
                  <input type="text" name="phone_no" />
                </label>
                  
                <label>
                  <p>Email:</p>
                  <input type="text" name="email" />
                </label>
                  
                <label>
                <p> Student ID:</p>
                  <input type="text" name="studentId" />
                </label>
                  
                <label>
                <p> Password:</p>
                  <input type="password" name="password"  />
                </label>
            </div>
           
                
              <button type="submit" className='mx-auto '>Sign Up</button>
          </form>
        </div>
      </main>
      {/* Navigation bar with transparent background */}
      <nav className="transparent-nav flex">
        <a href="/about" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>About UG</u>
        </a>
        <a href="/research" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Research</u>
        </a>
        <a href="/education" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Education</u>
        </a>
        <a href="/news" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>News</u>
        </a>
        <a href="/campus-life" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Campus Life</u>
        </a>
        <a href="/alumni" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Alumni</u>
        </a>
        <a href="/contact" style={{ fontFamily: 'Open Sans', color: 'grey', textDecoration: 'underline' }}>
          <u>Contact</u>
        </a>
      </nav>
    </div>
  );
}

export default LoginPage;
